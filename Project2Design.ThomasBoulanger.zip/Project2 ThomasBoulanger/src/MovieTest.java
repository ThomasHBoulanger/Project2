import static org.junit.Assert.*;

import org.junit.Test;

public class MovieTest {

	@Test
	public void testReadFile() {
		//assertequals or assertTrue should be put here to test
	}

	@Test
	public void testParseMovie() {
		//assertequals or assertTrue should be put here to test
	}

	@Test
	public void testCompareTo() {
		//assertequals or assertTrue should be put here to test
	}

}
