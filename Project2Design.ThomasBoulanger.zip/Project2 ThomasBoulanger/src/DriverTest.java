import static org.junit.Assert.*;

import org.junit.Test;

public class DriverTest {

	@Test
	public void testSortMovieTitle() {
		//assertequals or assertTrue should be put here to test
	}

	@Test
	public void testSortSeriesTitle() {
		//assertequals or assertTrue should be put here to test
	}

	@Test
	public void testSortMovieYear() {
		//assertequals or assertTrue should be put here to test
	}

	@Test
	public void testSortSeriesYear() {
		//assertequals or assertTrue should be put here to test
	}

}
