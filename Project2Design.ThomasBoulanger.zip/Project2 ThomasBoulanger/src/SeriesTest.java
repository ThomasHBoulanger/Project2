import static org.junit.Assert.*;

import org.junit.Test;

public class SeriesTest {

	@Test
	public void testReadFile() {
		//assertequals or assertTrue should be put here to test
	}

	@Test
	public void testParseSeries() {
		//assertequals or assertTrue should be put here to test
	}

	@Test
	public void testCompareTo() {
		//assertequals or assertTrue should be put here to test
	}

}
